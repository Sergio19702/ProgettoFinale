import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, AbstractControl } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../auth.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent implements OnInit {
  form!: FormGroup
  logUser!: any
  user = {username: '', password: '', email: '', role: ['']}
  constructor(private authSrv: AuthService, private router: Router, private fb: FormBuilder) { }

  ngOnInit(): void {
    this.authSrv.user$.subscribe((user)=>{
      this.logUser = user;
      })
    this.formInit()
  }


   onsubmit(form: any) {
      this.user.username = form.value.username
      this.user.password = form.value.password
      this.user.email = form.value.email
      this.user.role.splice(0,1)
      this.user.role.push(form.value.role)
      this.authSrv.registra(this.user).toPromise();
      alert('Registrazione avvenuta con successo');
      this.router.navigate(['/']);
  }

  formInit(){
    this.form = this.fb.group({
      username: new FormControl(''),
      password: new FormControl(''),
      email: new FormControl(''),
      role: new FormControl()

    })
  }

  controlloErrori(nome: string, error: string) {
    return this.form.get(nome)?.errors![error];
  }

  controlliForm(nome:string){
    return this.form.get(nome) as AbstractControl;
  }



}