import { Component, OnInit } from '@angular/core';
import { Fattura } from 'src/app/models/fattura';
import { FattureService } from 'src/app/services/fatture.service';

@Component({
  selector: 'app-fatture',
  templateUrl: './fatture.component.html',
  styleUrls: ['./fatture.component.scss']
})
export class FattureComponent implements OnInit {
  fatture: Fattura[] | undefined
  numeroPagina: number = 0;
  maxPagina!: number

  constructor(private  fattureSrv: FattureService) { }

  ngOnInit(): void {
    this.recuperaFatture()
  }

  /*PAGINATION*/

  public get pageNumberText(){
    return this.numeroPagina + 1;
  }

  paginaPrecedente(){
    if(this.numeroPagina > 0){
      this.numeroPagina--;
      this.recuperaFatture()
    }
  }

  paginaSuccessiva(){
    if((this.maxPagina - 2) > this.numeroPagina){
      this.numeroPagina++;
      this.recuperaFatture()
    }

  }

  /*FINE PAGINATION*/


  recuperaFatture(){
    this.fattureSrv.recuperaFatture(this.numeroPagina).subscribe((f)=>{
      this.maxPagina = f.totalPages
      this.fatture = f.content
      console.log(this.maxPagina)
    })
  }


  rimuoviFatture(id: number){
    if(confirm('sei sicuro di voler elimare la fattura ?')){
      this.fattureSrv.rimuoviFatture(id).subscribe(()=>{
            this.recuperaFatture()
          })
    }else{
      return
    }

  }




}