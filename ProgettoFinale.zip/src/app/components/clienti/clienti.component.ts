import { Component, OnInit } from '@angular/core';
import { Cliente } from 'src/app/models/cliente';
import { ClientiService } from 'src/app/services/clienti.service';

@Component({
  selector: 'app-clienti',
  templateUrl: './clienti.component.html',
  styleUrls: ['./clienti.component.scss'],
})
export class ClientiComponent implements OnInit {
  clienti: Cliente[] | undefined;
  numeroPagina: number = 0;
  maxPagina!: number;

  constructor(private clientiSrv: ClientiService) {}

  ngOnInit(): void {
    this.recuperaClienti();
  }

  /*PAGINATION*/

  public get pageNumberText() {
    return this.numeroPagina + 1;
  }

  paginaPrecedente() {
    if (this.numeroPagina > 0) {
      this.numeroPagina--;
      this.recuperaClienti();
    }
  }

  paginaSuccessiva() {
    if((this.maxPagina - 2) >= this.numeroPagina){
      this.numeroPagina++;
      this.recuperaClienti();
    }

  }

  /*FINE PAGINATION*/

  recuperaClienti() {
    this.clientiSrv.recuperaClienti(this.numeroPagina).subscribe((c) => {
      this.maxPagina = c.totalPages;
      this.clienti = c.content;
      console.log(this.maxPagina);
    });
  }

  elimina(id: number) {
    if (confirm('Sei sicuro di voler elimare il cliente?')) {
      this.clientiSrv.rimuoviCliente(id).subscribe(() => {
        this.recuperaClienti();
      });
    } else {
      return;
    }
  }
}